package com.kafka.example.KafkaDemo;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class KafkaController {

	@RequestMapping("/kafkaDemo")
	public String display()
	{
		System.out.println("kafka message");
		return "kafka message is displyed";
	}
}
