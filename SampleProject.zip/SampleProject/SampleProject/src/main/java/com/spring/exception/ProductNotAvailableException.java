package com.spring.exception;

public class ProductNotAvailableException extends RuntimeException {
	   private static final long serialVersionUID = 1L;
	}