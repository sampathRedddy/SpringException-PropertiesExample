package com.spring.boot;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
@EnableAutoConfiguration
public class AutoConfigurationFile {
	 @Bean
	   public MyBean myBean () {
	       return new MyBean();
	   }

	   @Bean
	   public MyWebController controller () {
	       return new MyWebController();
	   }

}
