package com.spring.boot;

public class MyBean {
	   public String getMessage () {
	       return "a message from MyBean";
	   }
	}
