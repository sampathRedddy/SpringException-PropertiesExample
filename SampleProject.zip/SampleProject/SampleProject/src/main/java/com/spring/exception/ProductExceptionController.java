package com.spring.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Controller
@ControllerAdvice
public class ProductExceptionController {
   @ExceptionHandler(value = ProductNotfoundException.class)
   public ResponseEntity<Object> exception(ProductNotfoundException exception) {
      return new ResponseEntity<>("Product not found", HttpStatus.NOT_FOUND);
   }
   
   @ExceptionHandler(value = ProductNotAvailableException.class)
   public ResponseEntity<Object> exception(ProductNotAvailableException exception) {
      return new ResponseEntity<>("Product not existed in the list", HttpStatus.NOT_FOUND);
   }
}
