package com.example.SampleProject;

public class PolindromExample {

	public static void main(String arg[])
	{
		int poliNum=153;

		int a=0,x,temp;

		temp=poliNum;
		while(poliNum>0)
		{
			x = poliNum % 10;
			poliNum = poliNum / 10;
			a = (a*10) + x;
		}

		if(temp==a) {
			System.out.println("Given numer is polindrom");
		}else {
			System.out.println("Givenn number is not polindrom");
		}
		
		
		int a1=0,temp1;
		int armNum=153;
		temp1=armNum;
		while(armNum>0)
		{
			x = armNum % 10;
			armNum = armNum / 10;
			a1 = a1 + (x*x*x);
		}
		
		if(temp1==a1) {
			System.out.println("Given numer is armstrong");
		}else {
			System.out.println("Givenn number is not armstrong");
		}
		
	}
	
}
