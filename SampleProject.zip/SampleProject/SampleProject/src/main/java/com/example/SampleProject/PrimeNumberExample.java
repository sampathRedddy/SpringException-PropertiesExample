package com.example.SampleProject;

public class PrimeNumberExample {

	public static void main(String[] args) {
		
		int n=9;
		boolean prim = false;
		for(int i=2;i<n;i++)
		{
			if(n%i==0)
			{
				prim=true;
				break;
			}
		}
		
		if(prim==true)
		{
			System.out.println("Given numer is not prime number");
		}
		else {
			System.out.println("Given number is prime number");
		}

	}

}
