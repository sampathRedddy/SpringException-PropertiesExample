package com.example.SampleProject;

public class SingletonExample {

	private static SingletonExample single;
	
	private SingletonExample() {
	}
	
	public static SingletonExample getInstance()
	{
		if(single!=null)
		{
			single=new SingletonExample();
		}
		return single;
	}
	
	public static void main(String argg[])
	{
		//NUmber format exception
		int a=Integer.parseInt("sampath");
		System.out.println("intere is :::::::::::;"+a);
		
		//Null pointer exception
		String str=null;
		System.out.println("stirng is ::::::::"+str.charAt(2));
		
		//IllegalArgument Exception
		Thread t = new Thread(); 
        Thread t1 = new Thread(); 
        t.setPriority(7); // Correct 
        t1.setPriority(12); // Exception 
	}
}
