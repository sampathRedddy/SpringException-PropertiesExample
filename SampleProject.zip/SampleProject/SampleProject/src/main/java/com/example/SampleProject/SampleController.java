package com.example.SampleProject;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SampleController {
@RequestMapping("/demo")
	public String display()
	{
		return "The first applicaiton ";
	}
}
