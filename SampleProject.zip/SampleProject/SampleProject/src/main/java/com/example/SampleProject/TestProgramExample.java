package com.example.SampleProject;

import java.util.Arrays;
import java.util.List;

public class TestProgramExample {

	public static void main(String arg[])
	
	{
		
		int n=11;
		
		if(n%2==0)
		{
			System.out.println("Given number is Even nmber "+n);
			
		}
		else {
			System.out.println("Given number is Odd nmber "+n);
		}
		
	List<Integer> list=Arrays.asList(1,2,3,4);
	list.stream().filter(list1 -> list1%2==0).forEach(System.out::println);
	
	
list.forEach(l->System.out.println(l));
list.stream().filter(l1->l1%2==0).forEach(System.out::println);
	

String str="sampath kumar reddy";
String replace = null;

for(int i=str.length()-1;i>=0;i--)
{
	replace=replace+str.charAt(i);
	}
System.out.println("reverse string is ::::::::::::"+replace);





	}
}
