package com.example.SampleProject;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Pattern;

public class StringExample {

	public static void main(String arg[])
	{
		String str= "sampath kumar reddy";
		HashMap<Character,Integer> h1 = new HashMap<Character ,Integer>();
		
		char[] strArray=str.toCharArray();
		System.out.println("================================");
		for(int c=0;c<strArray.length;c++)
		{
			System.out.println("Characters are :::::::::::;"+strArray[c]);
		}
		
		for(Character ch : strArray)
		{
			
		//}
		
		//for(int i=0;i<strArray.length;i++)
		//{
			if(h1.containsKey(ch))
			{
				h1.put(ch,h1.get(ch)+1);
			}
			else
			{
				h1.put(ch,1);
			}
		}
	
		//h1.entrySet();
		for(Map.Entry<Character, Integer> entry : h1.entrySet())
		{
			if(entry.getValue() > 1)
			{
				System.out.println(entry.getKey() +"============"+entry.getValue());
			}
			if(entry.getKey().equals('r'))
			{
				System.out.println("=============="+entry.getKey() +"============"+entry.getValue());
			}
		}
		
		
		/*
		 * int max_count = 0, res = -1;
		 * 
		 * for(Map.Entry<Character, Integer> val : h1.entrySet()) { if (max_count <
		 * val.getValue()) { res = val.getKey(); max_count = val.getValue(); } }
		 * 
		 * System.out.println("responses is ------------------"+res);
		 */
		
		String str1="sampath kumar reddy";
		String ss[]=str1.split("");
		
		for(int j=0;j<ss.length-1;j++)
		{
			System.out.println("strin gis :::::::;;"+ss[j]);
		}
		
		
		
		//Pattern pattern = Pattern.compile("[^0-9]");
	       Pattern pattern = Pattern.compile(".*\\D.*");
	       String [] inputs = {"123", "-123" , "123.12", "abcd123"};
	      
	       for(String input: inputs){
	           System.out.println( "does " + input + " is number : "
	                                + pattern.matcher(input).matches());
	       }

    
	       List< String> words = Arrays.asList(str1.split("\\s"));
	       System.out.println("size is :::::::;;"+words.size());
	     //Collections.reverse(words);
	     System.out.println("words are :::::::::::::::::"+words);
	     
	     StringBuilder sb = new StringBuilder(str1.length());
	     
	     for (int i = words.size() - 1; i >= 0; i--) {
	    	  sb.append(words.get(i));
	    	  sb.append(' ');
	    	  }
	    	 
	    	  System.out.println(sb);
		
		
	String s3="sas";
	String rever=null;
	
	for(int d=s3.length()-1;d>=0;d--)
	{
	rever=rever+s3.charAt(d);	
	}
	
	if(s3.equals(rever))
	{
		System.out.println("given string is polindrom");
	}
	else
	{
		System.out.println("given string is not polindrom");
	}	
		
		
	String str123=new String();
	String s12 = "geeksforgeeks"; 
	int len = s12.length(); 
    
    for (int i = 0; i < len; i++)  
    { 
        // character at i'th index of s 
        char c = s12.charAt(i); 
          
        System.out.println(c+":::::::::;;;index is s::::::::::::"+str123.indexOf(c));
        // if c is present in str, it returns 
        // the index of c, else it returns -1 
        if (str123.indexOf(c) < 0) 
        { 
            // adding c to str if -1 is returned 
            str123 += c; 
        } 
    } 
    
    System.out.println("string 123 is ::::::::::"+str123);
    
   // System.out.println("Remve the string ======="+s12.replace("g", ""));
    
    
    String gan=new String("gan");
    gan.indexOf("s");
    System.out.println(gan.indexOf("n"));
    
    
    String str4="samapt";
    int le = str4.length();
    int mid = le/2; 
    if (le%2==0){
    System.out.print("if condition is ::::::::;"+str4.charAt(mid-1));
    System.out.println(str4.charAt(mid));
    }else{
    System.out.println ("Elseif condition is ::::::::;"+str4.charAt(mid)); 
    }
    
    
    
    //Initialize array   
    int [] arr = new int [] {1, 2, 3, 4, 2, 7, 8, 8, 3};   
      
    System.out.println("Duplicate elements in given array: ");  
    //Searches for duplicate element  
    for(int i = 0; i < arr.length; i++) {  
        for(int j = i + 1; j < arr.length; j++) {  
            if(arr[i] == arr[j])  
                System.out.println("Duplicate values are :::::::::;"+arr[j]);  
        }  
    }  
    
	}
}
