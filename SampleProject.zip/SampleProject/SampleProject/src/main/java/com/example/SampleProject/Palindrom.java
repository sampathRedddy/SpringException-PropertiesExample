package com.example.SampleProject;

public class Palindrom {

	public static void main(String arg[])
	{
	int n=153;
	int x,temp,a=0,b=0;
	temp=n;
	
	while(n>0)
	{
		x=n%10;
		n=n/10;
		a=(a*10)+x;
		b=b+(x*x*x);
		
	}
		if(temp==a)
		{
			System.out.println("Given number is polindrom");
		}
		else
		{
			System.out.println("Given number is not polindrom");
		}
		
		if(temp==b)
		{
			System.out.println("Given number is armtrong");
		}
		else
		{
			System.out.println("Given number is not armstrong");
		}
		
	
	}
}
