package com.example.SampleProject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

public class HashcodeExample {

	public static void main(String arg[])
	{
		String s1=new String("sampath");
		String s2=new String(s1);
		
		System.out.println(s1.equals(s2));
		System.out.println(s1==s2);
		
		System.out.println("s1 hashcode :::::"+s1.hashCode());
		System.out.println("s2 hashcode :::::"+s2.hashCode());
		
		
		String s3=new String("ram");
		String s4="ram";
		
		System.out.println(s3.equals(s4));
		System.out.println(s3==s4);
		
		System.out.println("s3 hashcode :::::"+s3.hashCode());
		System.out.println("s4 hashcode :::::"+s4.hashCode());
		
		
		
		
		ArrayList list=new ArrayList();
		list.add("sam");
		list.add("ram");
		list.add(null);
		
		
		System.out.println("Arraylsit is :::::::::"+list);
		
		Set set=new HashSet();
		set.add("sam");
		set.add("ram");
		set.add("sam");
		set.add(null);
		set.add(null);
		
		System.out.println("Set is :::::::::"+set);
		
		HashMap<Integer,String> h1=new HashMap();
	    h1.put(1, "Sampath");
	    h1.put(1, "Sampath1");
	    h1.put(3, "Sampath12");
		
	    
	    Iterator it=h1.entrySet().iterator();
		while(it.hasNext())
		{
			Map.Entry entry=(Entry) it.next();
			System.out.println(entry.getKey()+"========="+entry.getValue());
		}
		
		for(Map.Entry<Integer,String> entry : h1.entrySet())
		{
			System.out.println(entry.getKey()+"============"+entry.getValue());
		}	
		
		String str="sampathreddy";
	
	int strlen=str.length();
	int mid=strlen/2;
	
	if(strlen%2==0)
	{
	 System.out.println(str.charAt(mid-1));
	 System.out.println(str.charAt(mid));	
	}
	else {
		System.out.println(str.charAt(mid));
	}
	
	
	
	}	
}
