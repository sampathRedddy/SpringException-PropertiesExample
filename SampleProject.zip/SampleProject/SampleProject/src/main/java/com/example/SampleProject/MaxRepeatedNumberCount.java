package com.example.SampleProject;

import java.util.HashMap; 
import java.util.Map; 
import java.util.Map.Entry; 
  
class MaxRepeatedNumberCount { 
      
    static int mostFrequent(int arr[], int n) 
    { 
          
        // Insert all elements in hash 
        Map<Integer, Integer> hp =  new HashMap<Integer, Integer>(); 
          
        for(int i = 0; i < n; i++) 
        { 
            int key = arr[i]; 
            if(hp.containsKey(key)) 
            { 
				/*
				 * int freq = hp.get(key); freq++;
				 */
                hp.put(key, hp.get(key)+1); 
            } 
            else
            { 
                hp.put(key, 1); 
            } 
        } 
          
        // find max frequency. 
        int max_count = 0, res = -1; 
          
        for(Entry<Integer, Integer> val : hp.entrySet()) 
        { 
        	System.out.println(val.getKey()+"==============="+val.getValue());
            if (max_count < val.getValue()) 
            { 
            	
                res = val.getKey();
                System.out.println("res :::::::::::::;;"+res);
                max_count = val.getValue();
                System.out.println("res :::::::::::::;;"+max_count);
            } 
        } 
          
        return res; 
    } 
     
    // Driver code 
    public static void main (String[] args) { 
          
        int arr[] = {1, 5, 2, 1, 3, 2, 1}; 
        int n = arr.length; 
          
     //   System.out.println(mostFrequent(arr, n)); 
        
        
        for(int i=0;i<arr.length;i++) {
        	for(int j=i+1;j<arr.length;j++)
        	{//System.out.println("jjjjjjjjjj==========="+j);
        		if(arr[i]==arr[j])
        		{
        			System.out.println("array is ::::::"+arr[j]);
        		}
        	}
        }
    } 
} 