package com.example.SampleProject;

public class MethodOver {

	public String display(String a)
	{
		System.out.println("dsly is ::::::;"+a);
		return "sampath";
	}
	
	public String display(int b)
	{
		System.out.println("dsly is ::::::;"+b);
		return "dfdsf";
	}
	
	public void message(String str)
	{
		System.out.println("illegal stagemnet :::::::::::;");
		
	}
	
	public static void main(String arg[]) {
		
		MethodOver m=new MethodOver();
		m.display("sampath");
		m.display(12);
		
		m.message(null);
		
		
		Thread t = new Thread(); 
        Thread t1 = new Thread(); 
        t.setPriority(7); // Correct 
        t1.setPriority(8); // Exception 
	}
}
