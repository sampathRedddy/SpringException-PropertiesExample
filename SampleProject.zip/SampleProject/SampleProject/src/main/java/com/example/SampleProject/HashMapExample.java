package com.example.SampleProject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.xml.bind.ValidationEventLocator;

public class HashMapExample {
	
	

	public static void main(String arg[]) {
		
		HashMap<Integer, String> h=new HashMap();
		h.put(1, "Sampath");
		h.put(2, "Chintu");
		
	//h.keySet();
	
		/*
		 * for(Integer s : h.keySet()) { System.out.println(s+"========"+h.get(s)); }
		 */
	
	h.forEach((k,v) -> {
		
	System.out.println(k+"====="+v);
	if("Sampath".equals(v)) {
		System.out.println("K value is :::::::::::"+v);
	}
	}
	);
	
	List<String> list=new ArrayList();
	list.add("sampath");
	list.add("chintu");
	list.add("ram");
	
	
	list.forEach(l -> System.out.println(l));
	
	list.forEach(l -> {
	if(l.equals("ram")) {	
	System.out.println(l);
	}
	});
	
	
	
	
	
	 List studentlist12=Arrays.asList(new Student(1,"Sampath"),
				new Student(2,"Ram")
				);

	 //studentlist.sort((Student s1, Student s2)->s1.getName().compareTo(s2.getName()));
	 
	 
	 
	 
	 List<Student1> studentlist = new ArrayList<Student1>();
     studentlist.add(new Student1("Jon", 22, 1001)); 
     studentlist.add(new Student1("Steve", 19, 1003)); 
     studentlist.add(new Student1("Kevin", 23, 1005)); 
     studentlist.add(new Student1("Ron", 20, 1010)); 
     studentlist.add(new Student1("Lucy", 18, 1111));
     System.out.println("Before Sorting the student data:"); 

     
     studentlist.forEach((s)->System.out.println(s));

     System.out.println("After Sorting the student data by Age:"); 

     
     studentlist.sort((Student1 s1, Student1 s2)->s1.getAge()-s2.getAge()); 

     
     studentlist.forEach((s)->System.out.println(s));         

     System.out.println("After Sorting the student data by Name:"); 
     //Lambda expression for sorting the list by student name       
     studentlist.sort((Student1 s1, Student1 s2)->s1.getName().compareTo(s2.getName())); 
     studentlist.forEach((s)->System.out.println(s));        
     System.out.println("After Sorting the student data by Id:");        
     //Lambda expression for sorting the list by student id 
     studentlist.sort((Student1 s1, Student1 s2)->s1.getId()-s2.getId()); 
     studentlist.forEach((s)->System.out.println(s));
	 
     
     
    HashSet s=new HashSet<String>();
    s.add("sampath");
    s.add("chintu");
    s.add("Ram");
    s.add(null);
    s.add("sampath");
 
   Iterator it=s.iterator();
   while(it.hasNext()) {
	   System.out.println("iterator is ::::::;"+it.next());
   }
    
    System.out.println("set is :::::::::::::::::;"+s);
    
    List li=new ArrayList();
    li.add("sampath");
    li.add("ram");
    li.add(null);
    li.add("ganga");
    li.add("ram");
    
    System.out.println("List is :::::::::::::::::;"+li);
    
    
    
    List<List<String>> late = new ArrayList();
    
    Map<String,String> gfg = new HashMap<String,String>(); 
    
    // enter name/url pair 
    gfg.put("GFG", "geeksforgeeks.org"); 
    gfg.put("Practice", "practice.geeksforgeeks.org"); 
    gfg.put("Code", "code.geeksforgeeks.org"); 
    gfg.put("Quiz", "quiz.geeksforgeeks.org"); 
     
     
    String str="SampathReddy";
    String str1 = new String();
    
    for(int i1=0;i1<str.length();i1++) {
    	char c=str.charAt(i1);
    	//System.out.println("characte is ::::::::::"+c);
    	if(str1.indexOf(c)<0) {
    		str1+=c;
    	}
    	System.out.println("str1 is :::::::::::::"+str1);
    }
    
    System.out.println("remove the duplicate string is :"+str1);
    
    String str12 = new String(); 
    int len = str.length(); 
      
    // loop to traverse the string and 
    // check for repeating chars using 
    // IndexOf() method in Java 
    for (int i = 0; i < len; i++)  
    { 
        // character at i'th index of s 
        char c = str.charAt(i); 
          
        // if c is present in str, it returns 
        // the index of c, else it returns -1 
        if (str.indexOf(c) < 0) 
        { 
            // adding c to str if -1 is returned 
            str12 += c; 
        } 
    } 
    System.out.println("remove the duplicate string is:::;;;;; :"+str12);
    
	}
}
