package com.example.SampleProject;

public class EvenNumber {

	public static  void main(String arg[])
	{
		
		int n=9;
		
		if(n%2==0)
		{
			System.out.println("even number");
		}
		else {
			System.out.println("Not an even number");
		}
		
		
		
		String s="Sampath";
		
		char c[]=s.toCharArray();
		
		for(int i=s.length()-1;i>=0;i--)
		{
		//	String reverse=(String)s.charAt(i);
			
		//	System.out.println(c[i]);
			
		System.out.println(s.charAt(i));
		}
		
		String s1[]=s.split("");
		
		for(int j=s1.length-1;j>=0;j--)
		{
			System.out.println("strig is :::::"+s1[j]);
		}
		
		System.out.println(s.length());
		int n1=153;
		
		System.out.println(n1%10);
		System.out.println(n1/10);
		
		
		
		
		
		
		
		
		
		
	}
}
